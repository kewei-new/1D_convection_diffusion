function result = rhs_variable_coefficient(uh,A,b)

result = -A*uh + b;